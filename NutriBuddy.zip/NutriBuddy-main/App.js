import React from "react";

import AppNavigator from "./src/AppNavigator";
// import Splash from "./Components/Splash";
// import Home from "./Components/Home";
// import Nutrition from "./Components/Nutrition";
// import Recipie from "./Components/Recipie";
// import Reminder from "./Components/Reminder";
// import Dietplan from "./Components/Dietplan";
// import Page from "./src/Components/Page";

const App = () => {
  return <AppNavigator />;
};

export default App;
