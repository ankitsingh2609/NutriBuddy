import { StyleSheet} from 'react-native';
const mystyle= StyleSheet.create({
    container:{
      flex:1,
      backgroundColor:'#c3f0a8'
    }
}
);

    export default mystyle;