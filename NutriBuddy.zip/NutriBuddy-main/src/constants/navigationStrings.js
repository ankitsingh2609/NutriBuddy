export default{
    LOGIN:"Login",
    REGISTER:"Register",
    HOME:"Home",
    SPLASH:"Splash",
}