import {AppRegistry} from "react-native";
import App from '../../App';

import {name as appName} from '../../app.json';


AppRegistry.registerComponent('appName', () => App);
//Auth Stack Screens
//export {default as Login} from '../Screens/Login';
//export {default as Register} from '../Screens/Register';

//Main Stack Screens
//export {default as Home} from '../Screens/Home';